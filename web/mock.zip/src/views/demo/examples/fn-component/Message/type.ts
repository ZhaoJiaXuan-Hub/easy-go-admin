export type Props = {
  type?: 'success' | 'warning' | 'error'
  content?: string
  duration?: number
}
