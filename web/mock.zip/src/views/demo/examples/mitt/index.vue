<template>
  <div>
    <a-space>
      <A></A>
      <B></B>
    </a-space>
  </div>
</template>

<script lang="ts" setup>
import A from './A.vue'
import B from './B.vue'
</script>

<style lang="scss" scoped></style>
