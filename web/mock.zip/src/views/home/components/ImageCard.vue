<template>
  <div class="image-card">
    <img class="animated-fade-up-1" src="@/assets/svgs/home-design.svg" />
  </div>
</template>

<style lang="scss" scoped>
.image-card {
  padding: 20px;
  box-sizing: border-box;
  background: var(--color-bg-1);
  img {
    width: 100%;
  }
}
</style>
