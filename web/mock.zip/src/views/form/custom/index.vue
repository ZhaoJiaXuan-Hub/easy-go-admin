<template>
  <div class="gi_page">
    <a-space direction="vertical" size="medium" fill>
      <Card1></Card1>
      <Card2></Card2>
      <Card4></Card4>
      <Card3></Card3>
    </a-space>
  </div>
</template>

<script setup lang="ts">
import Card1 from './components/Card1.vue'
import Card2 from './components/Card2.vue'
import Card3 from './components/Card3.vue'
import Card4 from './components/Card4.vue'
</script>

<style lang="scss" scoped></style>
