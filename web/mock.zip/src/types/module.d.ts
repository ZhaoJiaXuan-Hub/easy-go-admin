declare module 'nprogress'
declare module '@arco-design/color'
declare module 'qs'
