export interface AreaItem {
  label: string
  code: string
  children?: AreaItem[]
}
