<template>
  <svg width="17" height="17" viewBox="0 0 48 48" fill="none" stroke="currentColor" stroke-width="4">
    <path d="M24 12V36M18 17 24 12 30 17M30 31 24 36 18 31" stroke-width="3.5"></path>
    <path d="M6 5H42"></path>
    <path d="M6 43H42"></path>
  </svg>
</template>

<script lang="ts" setup></script>

<style lang="scss" scoped></style>
